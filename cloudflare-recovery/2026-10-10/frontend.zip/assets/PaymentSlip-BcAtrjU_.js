import{c as e,n as t,r as n}from"./createLucideIcon-BMtPJYff.js";import{t as r}from"./circle-check-big-eLNK_q4U.js";import{t as i}from"./clock-BIGOu39y.js";import{t as a}from"./download-Bg7wVOGX.js";var o=e(n(),1),s=t(),c=({type:e,title:t,name:n,email:c,amount:l,paymentMethod:u,transactionId:d,status:f,date:p,registrationId:m})=>{let h=(0,o.useRef)(null);return(0,s.jsxs)(`div`,{ref:h,className:`p-4 rounded-xl glass border border-border`,children:[(0,s.jsxs)(`div`,{className:`flex items-center justify-between mb-3`,children:[(0,s.jsx)(`h4`,{className:`text-sm font-semibold text-foreground`,children:`Payment Slip`}),(0,s.jsx)(`div`,{className:`flex items-center gap-2`,children:(0,s.jsxs)(`span`,{className:`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full ${f===`confirmed`?`bg-green-500/10 text-green-400`:f===`pending`?`bg-yellow-500/10 text-yellow-400`:`bg-red-500/10 text-red-400`}`,children:[f===`confirmed`?(0,s.jsx)(r,{size:10}):(0,s.jsx)(i,{size:10}),f===`unpaid`?`Unpaid`:f===`pending`?`Pending`:`Confirmed`]})})]}),(0,s.jsxs)(`div`,{className:`space-y-1.5 text-xs text-muted-foreground`,children:[(0,s.jsxs)(`div`,{className:`flex justify-between`,children:[(0,s.jsx)(`span`,{children:`Type:`}),(0,s.jsx)(`span`,{className:`text-foreground font-medium`,children:e})]}),(0,s.jsxs)(`div`,{className:`flex justify-between`,children:[(0,s.jsx)(`span`,{children:`Amount:`}),(0,s.jsxs)(`span`,{className:`text-foreground font-medium`,children:[`৳`,l]})]}),(0,s.jsxs)(`div`,{className:`flex justify-between`,children:[(0,s.jsx)(`span`,{children:`Method:`}),(0,s.jsx)(`span`,{className:`text-foreground font-medium`,children:u})]}),d&&(0,s.jsxs)(`div`,{className:`flex justify-between`,children:[(0,s.jsx)(`span`,{children:`TXN ID:`}),(0,s.jsx)(`span`,{className:`text-foreground font-medium`,children:d})]})]}),(0,s.jsxs)(`button`,{onClick:()=>{if(!h.current)return;let r=window.open(``,`_blank`);r&&(r.document.write(`
      <html><head><title>Payment Slip - ${t}</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 40px; max-width: 600px; margin: 0 auto; color: #1a1a2e; }
        .header { text-align: center; border-bottom: 2px solid #6366f1; padding-bottom: 16px; margin-bottom: 24px; }
        .header h1 { font-size: 20px; color: #6366f1; margin: 0 0 4px; }
        .header p { font-size: 12px; color: #666; margin: 0; }
        .status { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; margin: 12px 0; }
        .status.confirmed { background: #dcfce7; color: #166534; }
        .status.pending { background: #fef9c3; color: #854d0e; }
        .status.unpaid { background: #fee2e2; color: #991b1b; }
        .row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; font-size: 14px; }
        .row .label { color: #666; }
        .row .value { font-weight: 600; }
        .footer { margin-top: 24px; text-align: center; font-size: 11px; color: #999; }
        @media print { body { padding: 20px; } }
      </style></head><body>
      <div class="header">
        <h1>RUET IoT Club</h1>
        <p>Payment ${f===`unpaid`?`Voucher (Unpaid)`:f===`pending`?`Receipt (Pending Verification)`:`Receipt (Confirmed)`}</p>
      </div>
      <div style="text-align:center">
        <span class="status ${f}">${f===`unpaid`?`⏳ UNPAID`:f===`pending`?`⏳ PENDING VERIFICATION`:`✅ PAYMENT CONFIRMED`}</span>
      </div>
      <div class="row"><span class="label">Type</span><span class="value">${e.charAt(0).toUpperCase()+e.slice(1)} Registration</span></div>
      <div class="row"><span class="label">${e===`event`?`Event`:e===`course`?`Course`:`Membership`}</span><span class="value">${t}</span></div>
      <div class="row"><span class="label">Name</span><span class="value">${n}</span></div>
      <div class="row"><span class="label">Email</span><span class="value">${c}</span></div>
      <div class="row"><span class="label">Amount</span><span class="value">৳${l}</span></div>
      <div class="row"><span class="label">Payment Method</span><span class="value">${u}</span></div>
      <div class="row"><span class="label">Transaction ID</span><span class="value">${d||`N/A`}</span></div>
      <div class="row"><span class="label">Date</span><span class="value">${new Date(p).toLocaleString()}</span></div>
      ${m?`<div class="row"><span class="label">Ref ID</span><span class="value">${m.slice(0,8).toUpperCase()}</span></div>`:``}
      <div class="footer">
        <p>This is a computer-generated document. No signature required.</p>
        <p>RUET IoT Club — Rajshahi University of Engineering & Technology</p>
      </div>
      </body></html>
    `),r.document.close(),r.print())},className:`mt-3 w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-primary/10 text-primary text-xs font-semibold hover:bg-primary/20 transition-colors`,children:[(0,s.jsx)(a,{size:12}),` Download Slip`]})]})};export{c as t};